<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>

        /* Footer Styles */
        footer {
            background-color: #333;
            color: #fff;
            padding: 10px 20px;
            text-align: center;
        }

        footer a {
            color: #fff;
        }

        /* Copyright Section Styles */
        footer .copyright {
            margin-bottom: 10px;
        }

        /* Navigation in Footer Styles */
        footer ul {
            list-style: none;
        }

        footer ul li {
            display: inline;
            margin-right: 10px;
        }

    </style>
</head>
<body>
    <footer>
        <P class="copyright">
            All rights reserved &copy; Purrfect Picks
        </P>
        <uL>
            <li><a href="#">Terms</a></li>
            <li><a href="#">Privacy</a></li>
        </uL>
    </footer>
</body>
</html>